#version 400 compatibility
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define PROGRAM_DEFERRED2
#define vsh
#include "/program/d2_clouds_upscaling.vsh"
