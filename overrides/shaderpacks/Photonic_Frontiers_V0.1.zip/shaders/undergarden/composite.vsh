#version 400 compatibility
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define PROGRAM_COMPOSITE0
#define vsh
#include "/program/c0_vl.vsh"
