#version 400 compatibility
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define vsh
#include "/program/c2_dof.vsh"
