#version 400 compatibility
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define PROGRAM_WEATHER
#define fsh
#include "/program/gbuffers_weather.fsh"
