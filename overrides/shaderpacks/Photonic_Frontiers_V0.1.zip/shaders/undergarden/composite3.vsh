#version 400 compatibility
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define vsh
#include "/program/c3_taau_prep.vsh"
