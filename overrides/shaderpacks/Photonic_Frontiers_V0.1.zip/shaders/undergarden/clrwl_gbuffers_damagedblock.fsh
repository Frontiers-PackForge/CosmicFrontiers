#version 400 compatibility
#define IS_COLORWHEEL
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define PROGRAM_GBUFFERS_DAMAGEDBLOCK
#define fsh
#include "/program/clrwl_damagedblock.fsh"
