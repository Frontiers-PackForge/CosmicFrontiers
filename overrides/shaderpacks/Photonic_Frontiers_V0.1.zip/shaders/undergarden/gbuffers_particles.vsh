#version 400 compatibility
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define PROGRAM_GBUFFERS_PARTICLES
#define vsh
#include "/program/gbuffers_all_solid.vsh"
