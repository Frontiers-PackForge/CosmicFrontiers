#version 400 compatibility
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define PROGRAM_GBUFFERS_WATER
#define fsh
#include "/program/gbuffers_all_translucent.fsh"
