#version 400 compatibility
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define PROGRAM_GBUFFERS_DAMAGEDBLOCK
#define vsh
#include "/program/gbuffers_damagedblock.vsh"
