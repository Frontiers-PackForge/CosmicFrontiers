#version 400 compatibility
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define PROGRAM_GBUFFERS_BASIC
#define vsh
#include "/program/gbuffers_basic.vsh"
