#version 400 compatibility
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define PROGRAM_DEFERRED3
#define vsh
#include "/program/d3_ao.vsh"
