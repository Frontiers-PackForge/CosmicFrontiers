#version 400 compatibility
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define vsh
#include "/program/c12_bloom_gaussian_0.vsh"
