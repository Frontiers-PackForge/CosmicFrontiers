#version 400 compatibility
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define PROGRAM_DEFERRED0
#define fsh
#include "/program/d0_sky_map.fsh"
