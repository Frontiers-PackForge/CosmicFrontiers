#version 400 compatibility
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define PROGRAM_DEFERRED3
#define fsh
#include "/program/d3_ao.fsh"
