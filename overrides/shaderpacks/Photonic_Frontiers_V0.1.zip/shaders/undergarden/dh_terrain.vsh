#version 400 compatibility
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define PROGRAM_DH_TERRAIN
#define vsh
#include "/program/dh_terrain.vsh"
