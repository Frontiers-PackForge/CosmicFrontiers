#version 400 compatibility
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define PROGRAM_DEFERRED4
#define vsh
#include "/program/d4_deferred_shading.vsh"
