#version 400 compatibility
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define BLOOM_TILE_INDEX 2
#define vsh
#include "/program/c5_c10_bloom_downsample.vsh"
