#version 400 compatibility
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define PROGRAM_SHADOW
#define PROGRAM_SHADOW_WATER
#define fsh
#include "/program/shadow.fsh"
