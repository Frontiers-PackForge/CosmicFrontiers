#version 430
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define PROGRAM_SETUP
#include "/program/lpv/setup.csh"
