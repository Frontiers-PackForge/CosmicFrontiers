#version 400 compatibility
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define PROGRAM_DEFERRED0
#define vsh
#include "/program/d0_sky_map.vsh"
