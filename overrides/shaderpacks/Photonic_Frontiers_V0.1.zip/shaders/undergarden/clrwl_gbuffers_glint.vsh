#version 400 compatibility
#define IS_COLORWHEEL
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define PROGRAM_GBUFFERS_ARMOR_GLINT
#define vsh
#include "/program/clrwl_glint.vsh"
