#version 400 compatibility
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define PROGRAM_COMPOSITE1
#define vsh
#include "/program/c1_blend_layers.vsh"
