#version 400
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define PROGRAM_GBUFFERS_LINE
#define fsh
#include "/program/gbuffers_basic.fsh"
