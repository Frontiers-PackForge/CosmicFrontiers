#version 400 compatibility
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define PROGRAM_GBUFFERS_DAMAGEDBLOCK
#define fsh
#include "/program/gbuffers_damagedblock.fsh"
