#version 400 compatibility
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define vsh
#include "/program/c11_bloom_merge_buffers.vsh"
