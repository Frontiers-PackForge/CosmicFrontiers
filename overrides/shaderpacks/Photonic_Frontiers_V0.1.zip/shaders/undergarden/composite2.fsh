#version 400 compatibility
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define fsh
#include "/program/c2_dof.fsh"
