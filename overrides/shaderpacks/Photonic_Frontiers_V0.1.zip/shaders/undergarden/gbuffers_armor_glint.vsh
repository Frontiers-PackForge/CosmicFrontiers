#version 400 compatibility
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define PROGRAM_GBUFFERS_ARMOR_GLINT
#define vsh
#include "/program/gbuffers_armor_glint.vsh"
