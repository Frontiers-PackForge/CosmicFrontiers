#version 400 compatibility
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define PROGRAM_DEFERRED1
#define vsh
#include "/program/d1_clouds.vsh"
