#version 400 compatibility
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define fsh
#include "/program/c12_bloom_gaussian_0.fsh"
