#version 400 compatibility
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define PROGRAM_GBUFFERS_HAND_WATER
#define vsh
#include "/program/gbuffers_all_translucent.vsh"
