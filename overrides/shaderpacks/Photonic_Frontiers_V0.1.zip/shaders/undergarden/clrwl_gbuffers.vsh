#version 400 compatibility
#define IS_COLORWHEEL
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define PROGRAM_GBUFFERS_TERRAIN
#define PROGRAM_GBUFFERS_BLOCK
#define PROGRAM_GBUFFERS_ENTITIES
#define vsh
#include "/program/clrwl_solid.vsh"
