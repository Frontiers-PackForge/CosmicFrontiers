#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#include "/program/voxy_opaque.glsl"
