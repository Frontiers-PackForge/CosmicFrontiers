#version 400 compatibility
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define PROGRAM_GBUFFERS_TERRAIN
#define PROGRAM_GBUFFERS_TERRAIN_SOLID
#define vsh
#include "/program/gbuffers_all_solid.vsh"
