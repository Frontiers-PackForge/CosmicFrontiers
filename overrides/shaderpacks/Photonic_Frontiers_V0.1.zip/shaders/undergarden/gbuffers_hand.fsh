#version 400 compatibility
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define PROGRAM_GBUFFERS_HAND
#define fsh
#include "/program/gbuffers_all_solid.fsh"
