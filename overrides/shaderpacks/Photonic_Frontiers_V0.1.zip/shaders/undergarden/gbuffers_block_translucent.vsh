#version 400 compatibility
#define WORLD_NETHER
#define WORLD_UNDERGARDEN
#define PROGRAM_GBUFFERS_BLOCK_TRANSLUCENT
#define vsh
#include "/program/gbuffers_all_translucent.vsh"
