#if !defined INCLUDE_SKY_FRONTIERS_FIRMAMENT_ATMOSPHERE
#define INCLUDE_SKY_FRONTIERS_FIRMAMENT_ATMOSPHERE

#include "/include/misc/frontiers_firmament_tunables.glsl"

const vec3 frontiers_firmament_sun_direction = vec3(1.0, 0.0, 0.0);
const float frontiers_firmament_earth_limb_slope = 0.06875;
const float frontiers_firmament_sun_radius = 0.27;
const float frontiers_firmament_sun_halo_radius = 0.42;
const float frontiers_firmament_sun_horizon_mask_height = -0.04;
const float frontiers_firmament_sun_horizon_mask_feather = 0.025;

uniform sampler2D frontiersEarthTex;
uniform sampler2D frontiersSunTex;

float frontiers_firmament_hash(vec3 point) {
	point = fract(point * 0.1031);
	point += dot(point, point.yzx + 33.33);
	return fract((point.x + point.y) * point.z);
}

float frontiers_firmament_noise(vec3 point) {
	vec3 cell = floor(point);
	vec3 local = fract(point);
	local = local * local * (3.0 - 2.0 * local);
	float n000 = frontiers_firmament_hash(cell);
	float n100 = frontiers_firmament_hash(cell + vec3(1.0, 0.0, 0.0));
	float n010 = frontiers_firmament_hash(cell + vec3(0.0, 1.0, 0.0));
	float n110 = frontiers_firmament_hash(cell + vec3(1.0, 1.0, 0.0));
	float n001 = frontiers_firmament_hash(cell + vec3(0.0, 0.0, 1.0));
	float n101 = frontiers_firmament_hash(cell + vec3(1.0, 0.0, 1.0));
	float n011 = frontiers_firmament_hash(cell + vec3(0.0, 1.0, 1.0));
	float n111 = frontiers_firmament_hash(cell + vec3(1.0, 1.0, 1.0));
	float lower = mix(mix(n000, n100, local.x), mix(n010, n110, local.x), local.y);
	float upper = mix(mix(n001, n101, local.x), mix(n011, n111, local.x), local.y);
	return mix(lower, upper, local.z);
}

float frontiers_firmament_fbm(vec3 point) {
	float value = 0.0;
	float amplitude = 0.53;
	for (int octave = 0; octave < 4; ++octave) {
		value += frontiers_firmament_noise(point) * amplitude;
		point = point * 2.03 + vec3(1.71, -2.13, 0.83);
		amplitude *= 0.47;
	}
	return value;
}

float frontiers_firmament_step(float value, float levels) {
	return floor(clamp(value, 0.0, 1.0) * levels + 0.5) / levels;
}

vec3 frontiers_firmament_earth_srgb(vec3 color, vec3 direction) {
	float horizontal_length = length(direction.xz);
	if (direction.y < -0.0001 && horizontal_length > 0.0001) {
		float earth_progress = frontiers_firmament_earth_limb_slope * horizontal_length / -direction.y;
		if (earth_progress <= 1.0) {
			vec2 earth_uv = vec2(0.5) + direction.xz / horizontal_length * earth_progress * 0.5;
			vec4 earth = texture(frontiersEarthTex, earth_uv);
			color = mix(color, earth.rgb, earth.a);
		}
	}
	return color;
}

vec3 frontiers_firmament_sun_srgb(vec3 color, vec3 direction) {
	float sun_facing = dot(direction, frontiers_firmament_sun_direction);
	if (sun_facing > 0.0) {
		vec3 tangent = normalize(vec3(-frontiers_firmament_sun_direction.z, 0.0, frontiers_firmament_sun_direction.x));
		vec3 bitangent = normalize(cross(tangent, frontiers_firmament_sun_direction));
		vec2 sun_offset = vec2(dot(direction, tangent), dot(direction, bitangent)) / sun_facing;
		float horizon_visibility = smoothstep(
			frontiers_firmament_sun_horizon_mask_height,
			frontiers_firmament_sun_horizon_mask_height + frontiers_firmament_sun_horizon_mask_feather,
			direction.y
		);
		float halo = 1.0 - smoothstep(frontiers_firmament_sun_radius, frontiers_firmament_sun_halo_radius, length(sun_offset));
		color += vec3(1.0, 0.43, 0.14) * halo * 0.42 * horizon_visibility;
		if (max(abs(sun_offset.x), abs(sun_offset.y)) <= frontiers_firmament_sun_radius) {
			vec2 sun_uv = vec2(
				sun_offset.x / (2.0 * frontiers_firmament_sun_radius) + 0.5,
				0.5 - sun_offset.y / (2.0 * frontiers_firmament_sun_radius)
			);
			vec4 sun = texture(frontiersSunTex, sun_uv);
			color += sun.rgb * 1.30 * horizon_visibility;
		}
	}

	return color;
}

vec3 frontiers_firmament_sky_srgb(vec3 direction) {
	direction = normalize(direction);
	float height = direction.y;
	vec3 color;
	if (height >= 0.48) {
		color = mix(vec3(0.095, 0.075, 0.225), vec3(0.018, 0.020, 0.090), (height - 0.48) / 0.52);
	} else if (height >= 0.0) {
		color = mix(vec3(0.315, 0.135, 0.365), vec3(0.095, 0.075, 0.225), height / 0.48);
	} else if (height >= -0.42) {
		color = mix(vec3(0.315, 0.135, 0.365), vec3(0.025, 0.175, 0.620), -height / 0.42);
	} else {
		color = mix(vec3(0.025, 0.175, 0.620), vec3(0.008, 0.025, 0.155), (-height - 0.42) / 0.58);
	}
	float upper_sky = smoothstep(0.08, 0.52, height);
	float broad = frontiers_firmament_fbm(direction * 2.45 + vec3(1.20, -0.35, 2.10));
	float broken = frontiers_firmament_noise(direction * 5.20 + vec3(-2.30, 1.70, 0.40));
	float ridge = 1.0 - abs(broad * 2.0 - 1.0);
	float shoal = frontiers_firmament_step(smoothstep(0.48, 0.76, broad * 0.68 + ridge * 0.32), 4.0);
	float filament = frontiers_firmament_step(smoothstep(0.61, 0.82, ridge * 0.72 + broken * 0.28), 5.0);
	float dust = frontiers_firmament_step(smoothstep(0.56, 0.78, broken), 4.0);
	float solar_suppression = 1.0 - smoothstep(0.68, 0.94, dot(direction, frontiers_firmament_sun_direction));
	float nebula = upper_sky * solar_suppression;
	color += vec3(0.035, 0.090, 0.235) * shoal * nebula * 0.58;
	color += vec3(0.100, 0.310, 0.480) * filament * nebula * 0.23;
	color += vec3(0.190, 0.130, 0.320) * shoal * filament * nebula * 0.16;
	color *= 1.0 - dust * upper_sky * 0.10;
	float horizon_height = height >= 0.0 ? height : -height * 0.35;
	float horizon = max(0.0, 1.0 - horizon_height * 3.4);
	horizon *= horizon;
	float horizontal_length = max(length(direction.xz), 0.0001);
	float solar_facing = pow(max(0.0, dot(direction.xz / horizontal_length, frontiers_firmament_sun_direction.xz)), 6.0);
	color = mix(color, vec3(1.0, 0.40, 0.11), horizon * solar_facing * 0.82);
	color = floor(clamp(color, 0.0, 1.0) * 64.0 + 0.5) / 64.0;
	return color;
}

vec4 frontiers_firmament_ocean_layer(
	vec3 direction,
	vec3 camera_position,
	float animation_time,
	float layer_depth,
	float layer_opacity
);

vec3 frontiers_firmament_ocean_srgb(
	vec3 sky_color,
	vec3 direction,
	vec3 camera_position,
	float animation_time
) {
	float visibility = 1.0 - smoothstep(224.0, 256.0, abs(camera_position.y - 15.0));
	if (visibility <= 0.0) {
		return sky_color;
	}

	vec4 deep = frontiers_firmament_ocean_layer(direction, camera_position, animation_time, 1.0, 0.16);
	vec4 middle = frontiers_firmament_ocean_layer(direction, camera_position, animation_time, 0.5, 0.23);
	vec4 surface = frontiers_firmament_ocean_layer(direction, camera_position, animation_time, 0.0, 0.42);
	deep.a *= visibility;
	middle.a *= visibility;
	surface.a *= visibility;

	if (camera_position.y >= 18.625) {
		sky_color = mix(sky_color, deep.rgb, deep.a);
		sky_color = mix(sky_color, middle.rgb, middle.a);
		sky_color = mix(sky_color, surface.rgb, surface.a);
	} else if (camera_position.y >= 14.5) {
		sky_color = mix(sky_color, deep.rgb, deep.a);
		sky_color = mix(sky_color, surface.rgb, surface.a);
		sky_color = mix(sky_color, middle.rgb, middle.a);
	} else if (camera_position.y >= 9.125) {
		sky_color = mix(sky_color, surface.rgb, surface.a);
		sky_color = mix(sky_color, deep.rgb, deep.a);
		sky_color = mix(sky_color, middle.rgb, middle.a);
	} else {
		sky_color = mix(sky_color, surface.rgb, surface.a);
		sky_color = mix(sky_color, middle.rgb, middle.a);
		sky_color = mix(sky_color, deep.rgb, deep.a);
	}
	return sky_color;
}

float frontiers_firmament_hash21(vec2 value) {
	vec2 point = fract(value * vec2(123.34, 456.21));
	point += dot(point, point + 45.32);
	return fract(point.x * point.y);
}

float frontiers_firmament_periodic_value_noise(vec2 world_position, float cell_size, float lattice_period) {
	float world_period = cell_size * lattice_period;
	vec2 point = mod(world_position, vec2(world_period)) / cell_size;
	vec2 base = floor(point);
	vec2 blend = fract(point);
	blend = blend * blend * (3.0 - 2.0 * blend);
	vec2 base0 = mod(base, vec2(lattice_period));
	vec2 base1 = mod(base + 1.0, vec2(lattice_period));
	float southwest = frontiers_firmament_hash21(base0);
	float southeast = frontiers_firmament_hash21(vec2(base1.x, base0.y));
	float northwest = frontiers_firmament_hash21(vec2(base0.x, base1.y));
	float northeast = frontiers_firmament_hash21(base1);
	return mix(mix(southwest, southeast, blend.x), mix(northwest, northeast, blend.x), blend.y);
}

vec4 frontiers_firmament_ocean_layer(
	vec3 direction,
	vec3 camera_position,
	float animation_time,
	float layer_depth,
	float layer_opacity
) {
	const float tau = 6.28318530718;
	const float current_period = 768.0;
	float layer_base = -24.0 * layer_depth + 5.0 * layer_depth * layer_depth;
	float layer_y = 15.0 + layer_base;
	float vertical_delta = layer_y - camera_position.y;
	if (vertical_delta * direction.y <= 0.0) {
		return vec4(0.0);
	}

	float ray_distance = abs(direction.y) > 0.00001 ? vertical_delta / direction.y : 32768.0;
	if (ray_distance <= 0.0) {
		return vec4(0.0);
	}
	float sample_distance = min(ray_distance, 16384.0);
	vec2 world_position = camera_position.xz + direction.xz * sample_distance;
	float storm_time = mod(animation_time, 61440.0);
	float angular_scale = tau / current_period;
	vec2 position = mod(world_position, vec2(current_period)) * angular_scale;
	float advection = mod(storm_time * 7.5, current_period) * angular_scale;
	vec2 macro_layer_offset = vec2(317.0, 911.0) * layer_depth;
	vec2 detail_layer_offset = vec2(683.0, 257.0) * layer_depth;
	float organic_macro = frontiers_firmament_periodic_value_noise(
		world_position + vec2(storm_time * 0.8, -storm_time * 0.2) + macro_layer_offset,
		128.0,
		32.0
	);
	float organic_detail = frontiers_firmament_periodic_value_noise(
		world_position + vec2(storm_time * 7.5, storm_time * 0.5) + detail_layer_offset,
		64.0,
		32.0
	);
	float macro_centered = organic_macro * 2.0 - 1.0;
	float detail_centered = organic_detail * 2.0 - 1.0;
	float phase_warp = macro_centered * 4.2 + detail_centered * 1.35;
	float layer_phase = (layer_depth - 0.5) * 1.35;
	vec2 flowing_position = vec2(position.x + advection, position.y);
	float primary = sin(dot(flowing_position, vec2(7.0, 1.0)) + phase_warp + layer_phase);
	float crossing = sin(dot(flowing_position, vec2(11.0, -3.0)) - phase_warp * 0.61 - layer_phase * 1.25);
	float swell = sin(dot(flowing_position, vec2(3.0, 2.0)) + macro_centered * 1.9 + layer_phase * 0.40);
	float family = smoothstep(0.18, 0.82, organic_detail);
	float secondary = mix(swell, crossing, family);
	float wave_ridge = 0.5 + 0.5 * (primary * 0.56 + secondary * 0.34 + swell * 0.10);
	float wave_body = 0.5 + 0.5 * (primary * 0.46 + secondary * 0.31 + swell * 0.23);

	float surface_weight = 1.0 - layer_depth;
	float body = smoothstep(0.18, 0.78, wave_body);
	float shoulder = smoothstep(0.50, 0.86, wave_ridge);
	float bioluminescence = smoothstep(0.68, 0.94, wave_ridge);
	float hot_crest = smoothstep(0.86, 0.98, wave_ridge);
	float pigment = clamp(
		0.5 + 0.46 * macro_centered - 0.34 * detail_centered + 0.28 * macro_centered * detail_centered,
		0.0,
		1.0
	);
	float shoulder_pigment = clamp(0.5 + 0.55 * detail_centered - 0.20 * macro_centered, 0.0, 1.0);
	float colony_field = clamp(
		0.5 + 0.55 * detail_centered + 0.22 * macro_centered - 0.18 * macro_centered * detail_centered,
		0.0,
		1.0
	);
	float colony = smoothstep(0.20, 0.82, colony_field);
	vec3 deep = mix(vec3(0.008, 0.020, 0.078), vec3(0.018, 0.082, 0.205), surface_weight);
	vec3 body_color = mix(vec3(0.018, 0.125, 0.350), vec3(0.025, 0.245, 0.510), pigment);
	vec3 shoulder_color = mix(vec3(0.025, 0.275, 0.650), vec3(0.030, 0.510, 0.850), shoulder_pigment);
	vec3 crest_color = mix(vec3(0.070, 0.570, 0.900), vec3(0.180, 0.850, 0.980), colony);
	vec3 color = mix(deep, body_color, 0.20 + body * 0.34);
	color = mix(color, shoulder_color, shoulder * (0.22 + surface_weight * 0.30));
	float luminous_weight = bioluminescence * (0.40 + surface_weight * 0.30) * mix(0.62, 1.08, colony);
	color = mix(color, crest_color, clamp(luminous_weight, 0.0, 0.82));
	float bacterial_fleck = smoothstep(0.72, 0.94, organic_detail) * hot_crest;
	color += vec3(0.130, 0.310, 0.350) * bacterial_fleck * bacterial_fleck * 0.11;
	color *= mix(0.72, 1.0, surface_weight);

	float density = (0.81 + shoulder * 0.08 + bioluminescence * 0.09) * mix(0.97, 1.03, organic_macro);
	float horizon_progress = pow(
		clamp((ray_distance - 320.0) / (16384.0 - 320.0), 0.0, 1.0),
		1.0 / 3.0
	);
	if (ray_distance >= 320.0) {
		float inner_overlap = smoothstep(0.0, 0.18, horizon_progress);
		float distant_haze = smoothstep(0.24, 0.92, horizon_progress);
		float subsurface_fade = 1.0 - step(0.01, layer_depth) * smoothstep(0.68, 0.96, horizon_progress);
		color = mix(color, vec3(0.018, 0.145, 0.360), distant_haze * 0.42);
		density = mix(density, 0.98, distant_haze * 0.58) * inner_overlap * subsurface_fade;
	} else {
		float eye_separation = smoothstep(0.75, 8.0, abs(layer_y - camera_position.y));
		density *= mix(0.42, 1.0, eye_separation);
	}
	return vec4(color, clamp(density * layer_opacity * frontiers_firmament_ocean_opacity_scale, 0.0, 0.60));
}

float frontiers_firmament_wind_envelope(float world_y) {
	float lower = clamp((world_y - 104.0) / 16.0, 0.0, 1.0);
	float upper = clamp((232.0 - world_y) / 16.0, 0.0, 1.0);
	return min(lower, upper);
}

vec4 frontiers_firmament_wind_scattering(
	vec3 direction,
	vec3 camera_position,
	float ray_length,
	float animation_time
) {
	const int sample_count = 12;
	const float tau = 6.28318530718;
	vec3 scattering = vec3(0.0);
	float transmission = 1.0;
	float bounded_length = min(ray_length, 320.0);
	if (bounded_length <= 0.0) {
		return vec4(scattering, transmission);
	}

	float step_length = bounded_length / float(sample_count);
	for (int sample_index = 0; sample_index < sample_count; ++sample_index) {
		float distance_along_ray = (float(sample_index) + 0.5) * step_length;
		vec3 world_position = camera_position + direction * distance_along_ray;
		float envelope = frontiers_firmament_wind_envelope(world_position.y);
		if (envelope <= 0.0) {
			continue;
		}

		float regional = frontiers_firmament_periodic_value_noise(world_position.xz, 448.0, 32.0) * 2.0 - 1.0;
		float angle = 0.38 + regional * 0.46;
		vec2 normal = vec2(cos(angle), sin(angle));
		vec2 tangent = vec2(-normal.y, normal.x);
		float warp = frontiers_firmament_periodic_value_noise(world_position.xz + vec2(917.0, 353.0), 224.0, 32.0) * 2.0 - 1.0;
		float corridor_phase = dot(world_position.xz, normal) / 92.0 + warp * 1.7;
		float corridor = 1.0 - smoothstep(0.0, 0.24, abs(sin(corridor_phase)));
		float along = dot(world_position.xz, tangent) - animation_time * 22.0;
		float vertical_phase = world_position.y * 0.061;
		float macro = frontiers_firmament_periodic_value_noise(
			world_position.xz + vec2(animation_time * 2.1, -animation_time * 0.7),
			48.0,
			32.0
		);
		float broad = 0.5 + 0.5 * sin(along * tau / 64.0 + (macro - 0.5) * 4.8);
		float crossing = 0.5 + 0.5 * sin(along * tau / 37.0 - vertical_phase + warp * 5.0);
		float packet_phase = fract(along / 64.0 + warp * 3.7);
		float packet = smoothstep(0.0, 0.14, packet_phase) * (1.0 - smoothstep(0.30, 0.98, packet_phase));
		float streak = smoothstep(0.50, 0.89, broad * 0.42 + crossing * 0.22 + packet * 0.48);
		float filament = smoothstep(0.58, 0.90, crossing * 0.30 + packet * 0.70);
		float irregular = mix(0.54, 1.0, macro);
		float density = corridor * envelope * irregular * (0.035 + streak * 0.16 + filament * 0.075);
		density *= step_length / 18.0;
		float alpha = clamp(density, 0.0, 0.24);
		vec3 shadow = vec3(0.018, 0.090, 0.230);
		vec3 body = mix(vec3(0.030, 0.280, 0.550), vec3(0.040, 0.520, 0.740), macro);
		vec3 crest = mix(vec3(0.060, 0.380, 0.680), vec3(0.130, 0.660, 0.800), crossing);
		vec3 color = mix(shadow, body, 0.18 + streak * 0.55);
		color = mix(color, crest, clamp(filament * 0.38 + streak * 0.16, 0.0, 0.58));
		scattering += transmission * color * alpha;
		transmission *= 1.0 - alpha;
	}
	float opacity = 1.0 - transmission;
	return vec4(scattering / max(opacity, 0.0001), transmission);
}

#endif
