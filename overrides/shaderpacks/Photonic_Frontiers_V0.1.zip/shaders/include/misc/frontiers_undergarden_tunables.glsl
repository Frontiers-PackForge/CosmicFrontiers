#if !defined INCLUDE_MISC_FRONTIERS_UNDERGARDEN_TUNABLES
#define INCLUDE_MISC_FRONTIERS_UNDERGARDEN_TUNABLES

#include "/include/utility/color.glsl"

const float frontiers_abyss_transition_top = -40.0;
const float frontiers_abyss_transition_bottom = -80.0;
const float frontiers_abyss_layer_blend = 24.0;
const float frontiers_abyss_brightness_scale = 1.70;

const vec3 frontiers_undergarden_upper_srgb = vec3(0.13, 0.20, 0.16);
const vec3 frontiers_abyss_layer_0_srgb = vec3(0.155, 0.305, 0.285);
const vec3 frontiers_abyss_layer_1_srgb = vec3(0.20, 0.27, 0.34);
const vec3 frontiers_abyss_layer_2_srgb = vec3(0.22, 0.19, 0.30);
const vec3 frontiers_abyss_layer_3_srgb = vec3(0.21, 0.19, 0.25);
const vec3 frontiers_abyss_layer_4_srgb = vec3(0.29, 0.16, 0.18);

float frontiers_abyss_factor(float world_y) {
    return 1.0 - smoothstep(
        frontiers_abyss_transition_bottom,
        frontiers_abyss_transition_top,
        world_y
    );
}

float frontiers_below_layer(float world_y, float edge) {
    return 1.0 - smoothstep(
        edge - frontiers_abyss_layer_blend,
        edge + frontiers_abyss_layer_blend,
        world_y
    );
}

vec3 frontiers_abyss_layer_srgb(float world_y) {
    vec3 color = frontiers_abyss_layer_0_srgb;
    color = mix(
        color,
        frontiers_abyss_layer_1_srgb,
        frontiers_below_layer(world_y, -200.0)
    );
    color = mix(
        color,
        frontiers_abyss_layer_2_srgb,
        frontiers_below_layer(world_y, -400.0)
    );
    color = mix(
        color,
        frontiers_abyss_layer_3_srgb,
        frontiers_below_layer(world_y, -600.0)
    );
    color = mix(
        color,
        frontiers_abyss_layer_4_srgb,
        frontiers_below_layer(world_y, -800.0)
    );
    return color;
}

vec3 frontiers_undergarden_ambient(float world_y) {
    vec3 color_srgb = mix(
        frontiers_undergarden_upper_srgb,
        frontiers_abyss_layer_srgb(world_y),
        frontiers_abyss_factor(world_y)
    );
    return srgb_eotf_inv(color_srgb) * rec709_to_working_color;
}

float frontiers_abyss_ambient_scale(float world_y) {
    float scale = 8.5;
    scale = mix(scale, 9.5, frontiers_below_layer(world_y, -200.0));
    scale = mix(scale, 10.5, frontiers_below_layer(world_y, -400.0));
    scale = mix(scale, 11.5, frontiers_below_layer(world_y, -600.0));
    scale = mix(scale, 10.5, frontiers_below_layer(world_y, -800.0));
    return scale * frontiers_abyss_brightness_scale;
}

float frontiers_abyss_water_density(float world_y) {
    float density = 1.0;
    density = mix(density, 1.10, frontiers_below_layer(world_y, -200.0));
    density = mix(density, 1.20, frontiers_below_layer(world_y, -400.0));
    density = mix(density, 1.30, frontiers_below_layer(world_y, -600.0));
    density = mix(density, 1.40, frontiers_below_layer(world_y, -800.0));
    return density;
}

float frontiers_abyss_helmet_clarity(float fog_start, float fog_end) {
    float stir = clamp((1.0 - fog_start / 40.0) / 0.35, 0.0, 1.0);
    float baseline_far = 160.0 * (1.0 - 0.30 * stir);
    float far_ratio = fog_end / max(baseline_far, 1.0);
    return smoothstep(1.10, 1.17, far_ratio);
}

vec3 frontiers_abyss_water_absorption(float world_y, float helmet_clarity) {
    float depth = clamp((-60.0 - world_y) / 740.0, 0.0, 1.0);
    vec3 absorption = mix(
        vec3(0.075, 0.036, 0.023),
        vec3(0.10, 0.052, 0.036),
        depth
    );
    return absorption * frontiers_abyss_water_density(world_y) *
        mix(1.0, 0.62, helmet_clarity) *
        rec709_to_working_color;
}

vec3 frontiers_abyss_water_scattering(float helmet_clarity) {
    return vec3(mix(0.028, 0.018, helmet_clarity));
}

vec3 frontiers_abyss_water_ambient(float world_y, float helmet_clarity) {
    return frontiers_undergarden_ambient(world_y) *
        mix(2.4, 3.3, helmet_clarity) * frontiers_abyss_brightness_scale;
}

#endif
