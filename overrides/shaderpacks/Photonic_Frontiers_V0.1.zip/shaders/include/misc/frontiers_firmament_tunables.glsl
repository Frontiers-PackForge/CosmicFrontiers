#if !defined INCLUDE_MISC_FRONTIERS_FIRMAMENT_TUNABLES
#define INCLUDE_MISC_FRONTIERS_FIRMAMENT_TUNABLES

const float frontiers_firmament_ocean_opacity_scale = 0.40;

#endif
