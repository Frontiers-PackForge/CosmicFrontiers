#if defined WORLD_FIRMAMENT

#include "/include/misc/frontiers_firmament_tunables.glsl"

const float frontiers_current_tau = 6.28318530718;
const float frontiers_current_ocean_period = 768.0;
const float frontiers_current_ocean_speed = 7.5;
const float frontiers_current_ocean_uv_offset = 67108864.0;
const float frontiers_current_wind_v_offset = 4096.0;

#ifdef vsh

flat out int frontiers_current_kind;
out vec2 frontiers_current_uv;
out vec3 frontiers_current_world_position;
out float frontiers_current_strength;
out float frontiers_current_phase;
out float frontiers_current_mode;
out float frontiers_current_opacity;
out vec2 frontiers_current_world_xz;
out float frontiers_current_layer_depth;
out float frontiers_current_layer_opacity;
out float frontiers_current_wave_body;
out float frontiers_current_wave_ridge;
out float frontiers_current_organic_macro;
out float frontiers_current_organic_detail;
out float frontiers_current_horizon_progress;
out float frontiers_current_world_y;

float frontiers_current_hash21(vec2 value) {
	vec2 point = fract(value * vec2(123.34, 456.21));
	point += dot(point, point + 45.32);
	return fract(point.x * point.y);
}

float frontiers_current_periodic_value_noise(vec2 world_position, float cell_size, float lattice_period) {
	float world_period = cell_size * lattice_period;
	vec2 point = mod(world_position, vec2(world_period)) / cell_size;
	vec2 base = floor(point);
	vec2 blend = fract(point);
	blend = blend * blend * (3.0 - 2.0 * blend);
	vec2 base0 = mod(base, vec2(lattice_period));
	vec2 base1 = mod(base + 1.0, vec2(lattice_period));
	float southwest = frontiers_current_hash21(base0);
	float southeast = frontiers_current_hash21(vec2(base1.x, base0.y));
	float northwest = frontiers_current_hash21(vec2(base0.x, base1.y));
	float northeast = frontiers_current_hash21(base1);
	return mix(mix(southwest, southeast, blend.x), mix(northwest, northeast, blend.x), blend.y);
}

void frontiers_current_prepare_vertex(inout vec3 vertex_position) {
	float marker = gl_Color.b * 255.0;
	bool ocean_carrier = gl_MultiTexCoord0.x > 33554432.0;
	bool ocean_local = ocean_carrier && abs(marker - 2.0) < 0.25;
	bool ocean_horizon = ocean_carrier && abs(marker - 3.0) < 0.25;
	bool wind = gl_MultiTexCoord0.y >= frontiers_current_wind_v_offset - 0.5 &&
		gl_MultiTexCoord0.y <= frontiers_current_wind_v_offset + 1.5;
	vec2 ocean_uv = vec2(gl_MultiTexCoord0.x - frontiers_current_ocean_uv_offset, gl_MultiTexCoord0.y);
	frontiers_current_kind = ocean_local ? 1 : ocean_horizon ? 2 : wind ? 3 : 0;
	frontiers_current_uv = vec2(0.0);
	frontiers_current_world_position = vec3(0.0);
	frontiers_current_strength = 0.0;
	frontiers_current_phase = 0.0;
	frontiers_current_mode = 0.0;
	frontiers_current_opacity = 0.0;
	frontiers_current_world_xz = vec2(0.0);
	frontiers_current_layer_depth = 0.0;
	frontiers_current_layer_opacity = 0.0;
	frontiers_current_wave_body = 0.0;
	frontiers_current_wave_ridge = 0.0;
	frontiers_current_organic_macro = 0.0;
	frontiers_current_organic_detail = 0.0;
	frontiers_current_horizon_progress = 0.0;
	frontiers_current_world_y = 0.0;

	if (frontiers_current_kind == 3) {
		frontiers_current_uv = vec2(gl_MultiTexCoord0.x, gl_MultiTexCoord0.y - frontiers_current_wind_v_offset);
		frontiers_current_strength = gl_Color.r;
		frontiers_current_phase = gl_Color.g;
		frontiers_current_mode = gl_Color.b;
		frontiers_current_opacity = gl_Color.a;
		return;
	}
	if (frontiers_current_kind == 0) return;

	float storm_time = frameTimeCounter;
	float angular_scale = frontiers_current_tau / frontiers_current_ocean_period;
	vec2 position = mod(ocean_uv, vec2(frontiers_current_ocean_period)) * angular_scale;
	float advection = mod(storm_time * frontiers_current_ocean_speed,
		frontiers_current_ocean_period) * angular_scale;
	frontiers_current_layer_depth = gl_Color.r;
	frontiers_current_layer_opacity = gl_Color.a;
	frontiers_current_horizon_progress = gl_Color.g;
	vec2 macro_layer_offset = vec2(317.0, 911.0) * frontiers_current_layer_depth;
	vec2 detail_layer_offset = vec2(683.0, 257.0) * frontiers_current_layer_depth;
	frontiers_current_organic_macro = frontiers_current_periodic_value_noise(
		ocean_uv + vec2(storm_time * 0.8, -storm_time * 0.2) + macro_layer_offset, 128.0, 32.0);
	frontiers_current_organic_detail = frontiers_current_periodic_value_noise(
		ocean_uv + vec2(storm_time * frontiers_current_ocean_speed, storm_time * 0.5) +
		detail_layer_offset, 64.0, 32.0);
	float macro_centered = frontiers_current_organic_macro * 2.0 - 1.0;
	float detail_centered = frontiers_current_organic_detail * 2.0 - 1.0;
	float phase_warp = macro_centered * 4.2 + detail_centered * 1.35;
	float layer_phase = (frontiers_current_layer_depth - 0.5) * 1.35;
	vec2 flowing_position = vec2(position.x + advection, position.y);
	float primary = sin(dot(flowing_position, vec2(7.0, 1.0)) + phase_warp + layer_phase);
	float crossing = sin(dot(flowing_position, vec2(11.0, -3.0)) - phase_warp * 0.61 - layer_phase * 1.25);
	float swell = sin(dot(flowing_position, vec2(3.0, 2.0)) + macro_centered * 1.9 + layer_phase * 0.40);
	float family = smoothstep(0.18, 0.82, frontiers_current_organic_detail);
	float secondary = mix(swell, crossing, family);
	float height_signal = primary * 0.66 + secondary * 0.24 + swell * 0.10;
	frontiers_current_wave_ridge = 0.5 + 0.5 * (primary * 0.56 + secondary * 0.34 + swell * 0.10);
	frontiers_current_wave_body = 0.5 + 0.5 * (primary * 0.46 + secondary * 0.31 + swell * 0.23);
	float layer_base = -24.0 * frontiers_current_layer_depth +
		5.0 * frontiers_current_layer_depth * frontiers_current_layer_depth;
	float layer_amplitude = 6.0 - 6.75 * frontiers_current_layer_depth +
		2.5 * frontiers_current_layer_depth * frontiers_current_layer_depth;
	float amplitude_variation = mix(0.78, 1.18, frontiers_current_organic_macro) *
		mix(0.94, 1.06, frontiers_current_organic_detail);
	layer_amplitude *= clamp(amplitude_variation, 0.78, 1.10);
	float local_displacement = layer_base + height_signal * layer_amplitude;
	float horizon_eased = frontiers_current_horizon_progress * frontiers_current_horizon_progress *
		frontiers_current_horizon_progress;
	float horizon_radius = mix(320.0, 16384.0, horizon_eased);
	float horizon_bend = frontiers_current_horizon_progress * frontiers_current_horizon_progress *
		(3.0 - 2.0 * frontiers_current_horizon_progress);
	float horizon_displacement = height_signal * layer_amplitude * (92.0 / horizon_radius) * (1.0 - horizon_bend);
	vertex_position.y += frontiers_current_kind == 2 ? horizon_displacement : local_displacement;
	frontiers_current_world_xz = ocean_uv;
	frontiers_current_world_y = 24.0 + local_displacement;
}

#endif

#ifdef fsh

flat in int frontiers_current_kind;
in vec2 frontiers_current_uv;
in vec3 frontiers_current_world_position;
in float frontiers_current_strength;
in float frontiers_current_phase;
in float frontiers_current_mode;
in float frontiers_current_opacity;
in vec2 frontiers_current_world_xz;
in float frontiers_current_layer_depth;
in float frontiers_current_layer_opacity;
in float frontiers_current_wave_body;
in float frontiers_current_wave_ridge;
in float frontiers_current_organic_macro;
in float frontiers_current_organic_detail;
in float frontiers_current_horizon_progress;
in float frontiers_current_world_y;

float frontiers_current_hash21(vec2 value) {
	vec2 point = fract(value * vec2(123.34, 456.21));
	point += dot(point, point + 45.32);
	return fract(point.x * point.y);
}

float frontiers_current_value_noise(vec2 value) {
	vec2 base = floor(value);
	vec2 blend = fract(value);
	blend = blend * blend * (3.0 - 2.0 * blend);
	float southwest = frontiers_current_hash21(base);
	float southeast = frontiers_current_hash21(base + vec2(1.0, 0.0));
	float northwest = frontiers_current_hash21(base + vec2(0.0, 1.0));
	float northeast = frontiers_current_hash21(base + vec2(1.0, 1.0));
	return mix(mix(southwest, southeast, blend.x), mix(northwest, northeast, blend.x), blend.y);
}

vec4 frontiers_current_ocean_color() {
	float surface_weight = 1.0 - frontiers_current_layer_depth;
	float body = smoothstep(0.18, 0.78, frontiers_current_wave_body);
	float shoulder = smoothstep(0.50, 0.86, frontiers_current_wave_ridge);
	float bioluminescence = smoothstep(0.68, 0.94, frontiers_current_wave_ridge);
	float hot_crest = smoothstep(0.86, 0.98, frontiers_current_wave_ridge);
	float macro_centered = frontiers_current_organic_macro * 2.0 - 1.0;
	float detail_centered = frontiers_current_organic_detail * 2.0 - 1.0;
	float pigment = clamp(0.5 + 0.46 * macro_centered - 0.34 * detail_centered +
		0.28 * macro_centered * detail_centered, 0.0, 1.0);
	float shoulder_pigment = clamp(0.5 + 0.55 * detail_centered - 0.20 * macro_centered, 0.0, 1.0);
	float colony_field = clamp(0.5 + 0.55 * detail_centered + 0.22 * macro_centered -
		0.18 * macro_centered * detail_centered, 0.0, 1.0);
	float colony = smoothstep(0.20, 0.82, colony_field);
	vec3 deep = mix(vec3(0.008, 0.020, 0.078), vec3(0.018, 0.082, 0.205), surface_weight);
	vec3 body_color = mix(vec3(0.018, 0.125, 0.350), vec3(0.025, 0.245, 0.510), pigment);
	vec3 shoulder_color = mix(vec3(0.025, 0.275, 0.650), vec3(0.030, 0.510, 0.850), shoulder_pigment);
	vec3 crest_color = mix(vec3(0.070, 0.570, 0.900), vec3(0.180, 0.850, 0.980), colony);
	vec3 color = mix(deep, body_color, 0.20 + body * 0.34);
	color = mix(color, shoulder_color, shoulder * (0.22 + surface_weight * 0.30));
	float luminous_weight = bioluminescence * (0.40 + surface_weight * 0.30) * mix(0.62, 1.08, colony);
	color = mix(color, crest_color, clamp(luminous_weight, 0.0, 0.82));
	float bacterial_fleck = smoothstep(0.72, 0.94, frontiers_current_organic_detail) * hot_crest;
	color += vec3(0.130, 0.310, 0.350) * bacterial_fleck * bacterial_fleck * 0.11;
	color *= mix(0.72, 1.0, surface_weight);
	float density = (0.81 + shoulder * 0.08 + bioluminescence * 0.09) *
		mix(0.97, 1.03, frontiers_current_organic_macro);
	if (frontiers_current_kind == 2) {
		float inner_overlap = smoothstep(0.0, 0.18, frontiers_current_horizon_progress);
		float distant_haze = smoothstep(0.24, 0.92, frontiers_current_horizon_progress);
		float subsurface_fade = 1.0 - step(0.01, frontiers_current_layer_depth) *
			smoothstep(0.68, 0.96, frontiers_current_horizon_progress);
		color = mix(color, vec3(0.018, 0.145, 0.360), distant_haze * 0.42);
		density = mix(density, 0.98, distant_haze * 0.58) * inner_overlap * subsurface_fade;
	} else {
		float radial = length(frontiers_current_world_xz - cameraPosition.xz) / 384.0;
		density *= 1.0 - smoothstep(0.91, 1.0, radial);
		float eye_separation = smoothstep(0.75, 8.0, abs(frontiers_current_world_y - cameraPosition.y));
		density *= mix(0.42, 1.0, eye_separation);
	}
	return vec4(color * rec709_to_working_color,
		clamp(density * frontiers_current_layer_opacity * frontiers_firmament_ocean_opacity_scale, 0.0, 0.60));
}

vec4 frontiers_current_wind_color() {
	float storm_mode = smoothstep(0.30, 0.46, frontiers_current_mode) *
		(1.0 - smoothstep(0.58, 0.74, frontiers_current_mode));
	float updraft_mode = smoothstep(0.74, 0.94, frontiers_current_mode);
	float edge = sin(clamp(frontiers_current_uv.y, 0.0, 1.0) * 3.14159265);
	edge = pow(max(edge, 0.0), mix(1.55, 1.85, storm_mode));
	float travel_speed = mix(10.0, 17.0, updraft_mode);
	travel_speed = mix(travel_speed, 22.0, storm_mode);
	float packet_period = mix(40.0, 64.0, max(storm_mode, updraft_mode));
	float travel = frontiers_current_uv.x - frameTimeCounter * travel_speed;
	float flow = travel * frontiers_current_tau / packet_period + frontiers_current_phase * frontiers_current_tau;
	float time_cycle = frameTimeCounter * frontiers_current_tau / 64.0;
	float macro = frontiers_current_value_noise(frontiers_current_world_position.xz * 0.012 +
		vec2(cos(time_cycle), sin(time_cycle)) * 1.25);
	float detail = 0.5 + 0.25 * sin(flow * 2.0 + frontiers_current_world_position.y * 0.061 +
		frontiers_current_phase * 17.0) +
		0.25 * sin(flow * 3.0 - frontiers_current_uv.y * 4.4 + frontiers_current_phase * 9.0);
	float shred = 0.5 + 0.25 * sin(flow * 5.0 + frontiers_current_uv.y * 4.2 +
		frontiers_current_phase * 23.0) +
		0.25 * sin(flow * 7.0 - frontiers_current_uv.y * 2.7 + frontiers_current_phase * 13.0);
	float broad = 0.5 + 0.5 * sin(flow + (macro - 0.5) * 4.8);
	float crossing = 0.5 + 0.5 * sin(flow * 1.73 - detail * 5.2 + frontiers_current_phase * 5.0);
	float packet_phase = fract(travel / packet_period + frontiers_current_phase * 3.7);
	float packet = smoothstep(0.0, 0.14, packet_phase) * (1.0 - smoothstep(0.30, 0.98, packet_phase));
	float streak_signal = broad * 0.42 + crossing * 0.22 + packet * 0.48 + (shred - 0.5) * 0.14;
	float streak = smoothstep(0.50, 0.89, streak_signal);
	float filament_signal = crossing * 0.30 + packet * 0.70;
	float filament = smoothstep(0.58, 0.90, filament_signal) * mix(0.68, 1.0, detail) *
		mix(0.76, 1.0, shred);
	float storm_prominence = smoothstep(0.18, 0.60, frontiers_current_opacity);
	filament *= mix(1.0, mix(0.12, 1.0, storm_prominence), storm_mode);
	float irregular = mix(0.54, 1.0, macro) * mix(0.76, 1.0, detail);
	float distance_fade = 1.0 - smoothstep(mix(150.0, 190.0, storm_mode),
		mix(230.0, 290.0, storm_mode), distance(frontiers_current_world_position, cameraPosition));
	float height_fade = mix(1.0, smoothstep(0.0, 0.13, frontiers_current_uv.y) *
		(1.0 - smoothstep(0.87, 1.0, frontiers_current_uv.y)), updraft_mode);
	vec3 shadow = vec3(0.018, 0.090, 0.230);
	vec3 body = mix(vec3(0.030, 0.280, 0.550), vec3(0.040, 0.520, 0.740), macro);
	vec3 crest = mix(vec3(0.060, 0.380, 0.680), vec3(0.130, 0.660, 0.800), detail);
	vec3 color = mix(shadow, body, 0.18 + streak * 0.55);
	color = mix(color, crest, clamp(filament * 0.38 + streak * 0.16, 0.0, 0.58));
	color = mix(color, vec3(0.055, 0.330, 0.690), storm_mode * 0.18);
	color = mix(color, vec3(0.180, 0.760, 0.980), updraft_mode * 0.12);
	float alpha = edge * height_fade * distance_fade * frontiers_current_opacity *
		frontiers_current_strength * irregular;
	float storm_alpha = mix(0.065 + streak * 0.42,
		0.10 + streak * 0.62 + filament * 0.18, storm_prominence);
	alpha *= mix(0.16 + streak * 0.56 + filament * 0.28, storm_alpha, storm_mode);
	if (alpha < 0.004) discard;
	return vec4(color * rec709_to_working_color, clamp(alpha, 0.0, mix(0.46, 0.48, storm_mode)));
}

vec4 frontiers_current_color() {
	return frontiers_current_kind == 3 ? frontiers_current_wind_color() : frontiers_current_ocean_color();
}

#endif

#endif
