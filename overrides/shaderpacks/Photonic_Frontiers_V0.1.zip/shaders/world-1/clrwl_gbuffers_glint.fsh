#version 400 compatibility
#define IS_COLORWHEEL
#define WORLD_NETHER
#define PROGRAM_GBUFFERS_ARMOR_GLINT
#define fsh
#include "/program/clrwl_glint.fsh"
