#version 400 compatibility
#define IS_COLORWHEEL
#define WORLD_NETHER
#define PROGRAM_GBUFFERS_BLOCK_TRANSLUCENT
#define PROGRAM_GBUFFERS_ENTITIES_TRANSLUCENT
#define fsh
#include "/program/clrwl_translucent.fsh"
