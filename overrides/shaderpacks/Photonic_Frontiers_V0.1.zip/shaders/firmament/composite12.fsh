#version 400 compatibility
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define fsh
#include "/program/c12_bloom_gaussian_0.fsh"
