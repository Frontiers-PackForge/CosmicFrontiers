#version 430 compatibility
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#include "/program/d4a_generate_sky_sh.csh"
