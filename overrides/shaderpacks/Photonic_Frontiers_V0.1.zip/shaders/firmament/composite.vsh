#version 400 compatibility
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define PROGRAM_COMPOSITE0
#define vsh
#include "/program/c0_vl.vsh"
