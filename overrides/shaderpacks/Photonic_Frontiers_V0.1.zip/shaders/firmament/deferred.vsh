#version 400 compatibility
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define PROGRAM_DEFERRED0
#define vsh
#include "/program/d0_sky_map.vsh"
