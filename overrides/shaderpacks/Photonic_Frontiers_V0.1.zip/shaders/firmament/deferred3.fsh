#version 400 compatibility
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define PROGRAM_DEFERRED3
#define fsh
#include "/program/d3_ao.fsh"
