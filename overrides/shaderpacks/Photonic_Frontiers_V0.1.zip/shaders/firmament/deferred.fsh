#version 400 compatibility
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define PROGRAM_DEFERRED0
#define fsh
#include "/program/d0_sky_map.fsh"
