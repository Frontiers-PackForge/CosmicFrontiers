#version 400 compatibility
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define PROGRAM_COMPOSITE1
#define fsh
#include "/program/c1_blend_layers.fsh"
