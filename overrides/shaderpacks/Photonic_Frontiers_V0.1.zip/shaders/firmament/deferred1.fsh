#version 400 compatibility
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define PROGRAM_DEFERRED1
#define fsh
#include "/program/d1_clouds.fsh"
