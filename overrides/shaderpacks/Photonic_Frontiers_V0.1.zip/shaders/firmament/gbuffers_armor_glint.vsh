#version 400 compatibility
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define PROGRAM_GBUFFERS_ARMOR_GLINT
#define vsh
#include "/program/gbuffers_armor_glint.vsh"
