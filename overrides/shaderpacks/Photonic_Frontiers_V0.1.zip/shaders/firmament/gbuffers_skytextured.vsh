#version 410 compatibility
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define vsh
#include "/program/gbuffers_skytextured.vsh"
