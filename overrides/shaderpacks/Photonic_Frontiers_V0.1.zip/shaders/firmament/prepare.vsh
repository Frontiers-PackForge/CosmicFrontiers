#version 400 compatibility

#define vsh
#define PROGRAM_PREPARE
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT

#include "/program/p0_clouds_prep.vsh"
