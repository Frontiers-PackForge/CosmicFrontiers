#version 400 compatibility
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define PROGRAM_DEFERRED4
#define vsh
#include "/program/d4_deferred_shading.vsh"
