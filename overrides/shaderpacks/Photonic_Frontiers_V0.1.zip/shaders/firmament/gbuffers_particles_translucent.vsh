#version 400 compatibility
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define PROGRAM_GBUFFERS_PARTICLES_TRANSLUCENT
#define vsh
#include "/program/gbuffers_all_translucent.vsh"
