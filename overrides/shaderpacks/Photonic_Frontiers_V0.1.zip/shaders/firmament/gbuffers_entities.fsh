#version 400 compatibility
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define PROGRAM_GBUFFERS_ENTITIES
#define fsh
#include "/program/gbuffers_all_solid.fsh"
