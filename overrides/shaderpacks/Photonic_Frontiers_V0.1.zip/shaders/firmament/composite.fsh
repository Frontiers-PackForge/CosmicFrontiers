#version 400 compatibility
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define PROGRAM_COMPOSITE0
#define fsh
#include "/program/c0_vl.fsh"
