#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#include "/program/voxy_opaque.glsl"
