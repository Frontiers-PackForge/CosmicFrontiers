#version 400 compatibility
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define PROGRAM_GBUFFERS_BASIC
#define fsh
#include "/program/gbuffers_basic.fsh"
