#version 430
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define WORLD_NETHER
#define PROGRAM_SETUP
#include "/program/lpv/setup.csh"
