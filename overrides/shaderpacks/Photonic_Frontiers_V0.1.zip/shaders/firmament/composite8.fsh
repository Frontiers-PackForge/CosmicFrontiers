#version 400 compatibility
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define BLOOM_TILE_INDEX 3
#define fsh
#include "/program/c5_c10_bloom_downsample.fsh"
