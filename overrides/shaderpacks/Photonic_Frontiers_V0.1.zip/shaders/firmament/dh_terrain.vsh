#version 400 compatibility
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define PROGRAM_DH_TERRAIN
#define vsh
#include "/program/dh_terrain.vsh"
