#version 400 compatibility
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define PROGRAM_GBUFFERS_DAMAGEDBLOCK
#define fsh
#include "/program/gbuffers_damagedblock.fsh"
