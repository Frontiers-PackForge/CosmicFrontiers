#version 400 compatibility
#define IS_COLORWHEEL
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define PROGRAM_GBUFFERS_ARMOR_GLINT
#define fsh
#include "/program/clrwl_glint.fsh"
