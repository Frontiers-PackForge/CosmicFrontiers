#version 400 compatibility
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define PROGRAM_WEATHER
#define fsh
#include "/program/gbuffers_weather.fsh"
