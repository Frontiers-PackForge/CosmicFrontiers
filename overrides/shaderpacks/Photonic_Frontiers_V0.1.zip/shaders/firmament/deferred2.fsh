#version 400 compatibility
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define PROGRAM_DEFERRED2
#define fsh
#include "/program/d2_clouds_upscaling.fsh"
