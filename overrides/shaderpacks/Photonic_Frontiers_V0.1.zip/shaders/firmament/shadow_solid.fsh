#version 400 compatibility
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define PROGRAM_SHADOW
#define PROGRAM_SHADOW_SOLID
#define fsh
#include "/program/shadow.fsh"
