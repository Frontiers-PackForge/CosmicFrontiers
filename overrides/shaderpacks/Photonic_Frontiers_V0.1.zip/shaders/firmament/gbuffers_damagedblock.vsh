#version 400 compatibility
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define PROGRAM_GBUFFERS_DAMAGEDBLOCK
#define vsh
#include "/program/gbuffers_damagedblock.vsh"
