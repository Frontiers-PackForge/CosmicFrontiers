#version 400 compatibility
#define IS_COLORWHEEL
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define PROGRAM_GBUFFERS_BLOCK_TRANSLUCENT
#define PROGRAM_GBUFFERS_ENTITIES_TRANSLUCENT
#define vsh
#include "/program/clrwl_translucent.vsh"
