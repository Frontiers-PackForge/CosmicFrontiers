#version 400 compatibility
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT

void main() { gl_Position = vec4(-1.0); }
