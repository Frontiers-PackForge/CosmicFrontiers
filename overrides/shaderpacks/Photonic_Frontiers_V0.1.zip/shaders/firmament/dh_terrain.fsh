#version 400 compatibility
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define PROGRAM_DH_TERRAIN
#define fsh
#include "/program/dh_terrain.fsh"
