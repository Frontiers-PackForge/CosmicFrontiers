#version 400
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define PROGRAM_GBUFFERS_LINE
#define vsh
#include "/program/gbuffers_basic.vsh"
