#version 400 compatibility
#define IS_COLORWHEEL
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define PROGRAM_GBUFFERS_TERRAIN
#define PROGRAM_GBUFFERS_BLOCK
#define PROGRAM_GBUFFERS_ENTITIES
#define fsh
#include "/program/clrwl_solid.fsh"
