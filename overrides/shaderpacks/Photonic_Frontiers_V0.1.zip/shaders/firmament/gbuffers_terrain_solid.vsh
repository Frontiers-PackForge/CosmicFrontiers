#version 400 compatibility
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define PROGRAM_GBUFFERS_TERRAIN
#define PROGRAM_GBUFFERS_TERRAIN_SOLID
#define vsh
#include "/program/gbuffers_all_solid.vsh"
