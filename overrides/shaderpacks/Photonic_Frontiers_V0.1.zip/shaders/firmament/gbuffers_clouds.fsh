#version 400 compatibility
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT

void main() { discard; }
