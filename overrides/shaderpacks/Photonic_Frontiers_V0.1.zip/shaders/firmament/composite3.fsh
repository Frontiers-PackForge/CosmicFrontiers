#version 400 compatibility
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define fsh
#include "/program/c3_taau_prep.fsh"
