#version 400 compatibility
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define PROGRAM_SHADOW
#define PROGRAM_SHADOW_WATER
#define fsh
#include "/program/shadow.fsh"
