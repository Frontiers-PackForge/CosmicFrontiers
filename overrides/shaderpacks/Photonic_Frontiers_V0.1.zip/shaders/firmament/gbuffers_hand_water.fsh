#version 400 compatibility
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define PROGRAM_GBUFFERS_HAND_WATER
#define fsh
#include "/program/gbuffers_all_translucent.fsh"
