#version 400 compatibility
#define WORLD_OVERWORLD
#define WORLD_FIRMAMENT
#define vsh
#include "/program/c15_fxaa.vsh"
